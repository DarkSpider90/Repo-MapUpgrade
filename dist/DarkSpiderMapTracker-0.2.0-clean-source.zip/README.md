# DarkSpider Map Tracker

Standalone configurable BepInEx/Harmony map tracker for R.E.P.O.

## Features

- Enemy arrows on the map.
- Player arrows on the map.
- Small generated triangle sprite only; no asset bundles or external resources.
- Enemy color presets plus optional custom hex.
- Player color presets, custom hex, or player equipped head/body color.
- Optional outline with color presets plus optional custom hex.
- Separate enemy/player arrow scale.
- Map zoom multiplier.
- Configurable zoom hotkeys while the map is open.

## Build

PowerShell example:

```powershell
$env:REPO_MANAGED="D:\SteamLibrary\steamapps\common\REPO\REPO_Data\Managed"
$env:BEPINEX_CORE="D:\SteamLibrary\steamapps\common\REPO\BepInEx\core"
dotnet build .\DarkSpiderMapTracker\DarkSpiderMapTracker.csproj -c Release
```

Result:

```text
DarkSpiderMapTracker\bin\Release\netstandard2.1\DarkSpiderMapTracker.dll
```

Put the dll into:

```text
BepInEx\plugins\DarkSpiderMapTracker\DarkSpiderMapTracker.dll
```

## Config

Generated file:

```text
BepInEx\config\DarkSpider90.MapTracker.cfg
```

Main options:

- `General.ModEnabled`
- `Enemies.ShowEnemyArrows`
- `Enemies.EnemyArrowColor`
- `Enemies.EnemyCustomHex`
- `Enemies.EnemyArrowScale`
- `Players.ShowPlayerArrows`
- `Players.PlayerArrowColor`
- `Players.PlayerCustomHex`
- `Players.PlayerArrowScale`
- `Outline.OutlineEnabled`
- `Outline.OutlineColor`
- `Outline.OutlineCustomHex`
- `Map Zoom.MapZoomMultiplier`
- `Map Zoom.ZoomInKey`
- `Map Zoom.ZoomOutKey`
- `Map Zoom.ZoomStep`
