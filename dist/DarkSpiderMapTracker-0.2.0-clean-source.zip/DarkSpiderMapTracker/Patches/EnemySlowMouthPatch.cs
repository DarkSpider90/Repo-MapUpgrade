using HarmonyLib;

namespace MapUpgrade.Patches
{
    [HarmonyPatch(typeof(EnemySlowMouth))]
    internal static class EnemySlowMouthPatch
    {
        [HarmonyPatch("UpdateStateRPC")]
        [HarmonyPostfix]
        private static void UpdateStateRPC(EnemySlowMouth __instance, Enemy ___enemy)
        {
            if (__instance == null || ___enemy == null)
                return;

            PlayerAvatar playerTarget = AccessTools.Field(typeof(EnemySlowMouth), "playerTarget")?.GetValue(__instance) as PlayerAvatar;
            EnemyParent enemyParent = AccessTools.Field(typeof(Enemy), "EnemyParent")?.GetValue(___enemy) as EnemyParent;
            if (playerTarget == null || enemyParent == null)
                return;

            if (__instance.currentState == EnemySlowMouth.State.Attached)
            {
                Plugin.Instance?.HideFromMap(enemyParent);
                Plugin.Instance?.SwapOnMap(enemyParent, playerTarget);
            }
            else if (__instance.currentState == EnemySlowMouth.State.Detach)
            {
                Plugin.Instance?.SwapOnMap(playerTarget, enemyParent);
                Plugin.Instance?.ShowToMap(enemyParent);
            }
        }
    }
}
