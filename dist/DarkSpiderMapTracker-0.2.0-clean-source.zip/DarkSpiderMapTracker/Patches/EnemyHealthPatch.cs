using HarmonyLib;

namespace MapUpgrade.Patches
{
    [HarmonyPatch(typeof(EnemyHealth))]
    internal static class EnemyHealthPatch
    {
        [HarmonyPatch("DeathRPC")]
        [HarmonyPostfix]
        private static void DeathRPC(Enemy ___enemy)
        {
            if (___enemy == null)
                return;

            EnemyParent enemyParent = AccessTools.Field(typeof(Enemy), "EnemyParent")?.GetValue(___enemy) as EnemyParent;
            if (enemyParent != null)
                Plugin.Instance?.HideFromMap(enemyParent);
        }
    }
}
