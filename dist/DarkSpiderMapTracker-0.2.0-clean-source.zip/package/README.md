# DarkSpider Map Tracker

Standalone configurable map tracker for R.E.P.O.

Shows enemies and players as small triangle arrows on the vanilla map.

## Configurable

- Enable/disable the whole mod.
- Show/hide enemies.
- Show/hide players.
- Enemy color presets or custom hex.
- Player color presets, custom hex, or player equipped color.
- Optional outline and outline color.
- Separate enemy/player arrow size.
- Map zoom multiplier and zoom hotkeys.
