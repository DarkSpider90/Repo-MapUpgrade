# 0.2.0

- Removed asset bundle loading and MoreUpgrades resource fallback.
- Kept only generated small triangle arrows.
- Reduced config to the intended core options.
- Default arrow scale is now 0.25.
- Added color presets plus custom hex fields.
- Added map zoom hotkeys.
- Removed unused config entries and unused code.
