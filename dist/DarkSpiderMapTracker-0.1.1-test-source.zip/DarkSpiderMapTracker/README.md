# DarkSpider Map Tracker

First test build source package.

This mod separates the map player/enemy tracker idea from MoreUpgrades and makes it a standalone configurable BepInEx/Harmony mod.

## Current test features

- Player arrows on the map.
- Enemy arrows on the map.
- Player arrows can use the player's visual/head color.
- Enemy arrows are configurable, red by default.
- Thin black outline behind arrows.
- Configurable map zoom multiplier.
- Uses the MoreUpgrades-style event flow:
  - `EnemyParent.Setup`
  - `EnemyParent.SpawnRPC`
  - `EnemyParent.DespawnRPC`
  - `EnemyHealth.DeathRPC`
  - `PlayerAvatar.LateStart`
  - `PlayerAvatar.ReviveRPC`
  - `PlayerAvatar.PlayerDeathRPC`
  - `Map.Update`
  - `Map.Awake`

## Build

PowerShell example:

```powershell
$env:REPO_MANAGED="D:\SteamLibrary\steamapps\common\REPO\REPO_Data\Managed"
$env:BEPINEX_CORE="D:\SteamLibrary\steamapps\common\REPO\BepInEx\core"
dotnet build .\DarkSpiderMapTracker\DarkSpiderMapTracker.csproj -c Release
```

Result:

```text
DarkSpiderMapTracker\bin\Release\netstandard2.1\DarkSpiderMapTracker.dll
```

Put the dll into:

```text
BepInEx\plugins\DarkSpiderMapTracker\DarkSpiderMapTracker.dll
```

## Important

This is test 0.1.1. It is meant to verify:

1. arrows appear;
2. enemies hide/show correctly;
3. player colors are correct;
4. zoom multiplier behaves correctly;
5. no console spam.

