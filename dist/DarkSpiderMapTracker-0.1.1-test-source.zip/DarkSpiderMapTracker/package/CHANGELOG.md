# 0.1.1

- First test source build.
- Added standalone player/enemy map arrows.
- Added configurable player/enemy colors.
- Added player head color mode.
- Added black arrow outline.
- Added map zoom multiplier.
