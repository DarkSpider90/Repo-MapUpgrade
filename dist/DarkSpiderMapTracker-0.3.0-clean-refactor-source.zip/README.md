# DarkSpider Map Tracker 0.3.0 clean refactor

Clean standalone R.E.P.O. BepInEx map tracker.

## Features

- Enemy arrows on the map
- Player arrows on the map
- Player arrow color from HeadTopMesh color
- Preset/hex colors
- Player/enemy arrow scale
- Outline for visibility on white/gray player colors
- Map zoom multiplier
- Mouse wheel and/or keyboard zoom controls
- Hides dead player arrows and shows them again on revive

## Build

PowerShell example:

```powershell
$env:REPO_MANAGED="D:\Games\Steam\steamapps\common\REPO\REPO_Data\Managed"
$env:BEPINEX_CORE="D:\Games\Steam\steamapps\common\REPO\BepInEx\core"

dotnet build .\DarkSpiderMapTracker\DarkSpiderMapTracker.csproj -c Release
```

Output:

```text
DarkSpiderMapTracker\bin\Release\DarkSpiderMapTracker.dll
```

Delete the old config before testing this refactor:

```text
BepInEx/config/DarkSpider90.MapTracker.cfg
```
