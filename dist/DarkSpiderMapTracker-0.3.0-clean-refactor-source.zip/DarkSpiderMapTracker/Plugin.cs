using BepInEx;
using HarmonyLib;
using System.Reflection;

namespace DarkSpider.MapTracker
{
    [BepInPlugin(ModGuid, ModName, ModVersion)]
    internal sealed class Plugin : BaseUnityPlugin
    {
        private const string ModGuid = "DarkSpider90.MapTracker";
        private const string ModName = "DarkSpider Map Tracker";
        private const string ModVersion = "0.3.0";

        internal static Plugin Instance { get; private set; }

        internal PluginConfig Settings { get; private set; }
        internal MapTrackerController Tracker { get; private set; }
        internal MapZoomController Zoom { get; private set; }

        private Harmony _harmony;

        private void Awake()
        {
            Instance = this;

            Settings = new PluginConfig(Config);
            Tracker = new MapTrackerController(this, Settings);
            Zoom = new MapZoomController(Settings);

            _harmony = new Harmony(ModGuid);
            _harmony.PatchAll(Assembly.GetExecutingAssembly());

            Logger.LogInfo($"{ModName} {ModVersion} loaded.");
        }

        private void OnDestroy()
        {
            _harmony?.UnpatchSelf();
            Tracker?.Clear();
            Zoom?.ResetZoom();
        }

        internal void OnMapAwake(Map map)
        {
            Tracker?.OnMapAwake(map);
            Zoom?.CaptureDefaultZoom();
        }

        internal void TickMap(Map map)
        {
            if (map == null || Map.Instance == null)
                return;

            if (!SemiFunc.RunIsLevel())
            {
                Tracker?.SetAllVisible(false);
                Zoom?.ResetZoom();
                return;
            }

            if (!Settings.ModEnabled.Value)
            {
                Tracker?.SetAllVisible(false);
                Zoom?.ResetZoom();
                return;
            }

            Zoom?.Tick();
            Tracker?.Tick(map);
        }

        internal void RegisterToMap(UnityEngine.Component component)
        {
            if (Settings.ModEnabled.Value)
                Tracker?.Register(component);
        }

        internal void ShowToMap(UnityEngine.Component component)
        {
            Tracker?.Show(component);
        }

        internal void HideFromMap(UnityEngine.Component component)
        {
            Tracker?.Hide(component);
        }

        internal void SwapOnMap(UnityEngine.Component component, UnityEngine.Component fromComponent)
        {
            Tracker?.SwapCategory(component, fromComponent);
        }
    }
}
