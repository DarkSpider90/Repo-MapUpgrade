using HarmonyLib;
using System;
using System.Reflection;
using UnityEngine;

namespace DarkSpider.MapTracker
{
    internal static class ReflectionCache
    {
        private static readonly FieldInfo EnemyParentEnemyField = AccessTools.Field(typeof(EnemyParent), "Enemy");
        private static readonly FieldInfo EnemyFieldEnemyParent = AccessTools.Field(typeof(Enemy), "EnemyParent");
        private static readonly FieldInfo PlayerIsDisabledField = AccessTools.Field(typeof(PlayerAvatar), "isDisabled");
        private static readonly FieldInfo PlayerCosmeticsColorsEquippedField = AccessTools.Field(typeof(PlayerCosmetics), "colorsEquipped");
        private static readonly FieldInfo EnemySlowMouthPlayerTargetField = AccessTools.Field(typeof(EnemySlowMouth), "playerTarget");

        private static readonly Type InputType = AccessTools.TypeByName("UnityEngine.Input");
        private static readonly PropertyInfo InputMouseScrollDeltaProperty = AccessTools.Property(InputType, "mouseScrollDelta");
        private static readonly MethodInfo InputGetKeyDownMethod = AccessTools.Method(InputType, "GetKeyDown", new[] { typeof(KeyCode) });

        internal static Enemy GetEnemy(EnemyParent enemyParent)
        {
            if (enemyParent == null || EnemyParentEnemyField == null)
                return null;

            return EnemyParentEnemyField.GetValue(enemyParent) as Enemy;
        }

        internal static EnemyParent GetEnemyParent(Enemy enemy)
        {
            if (enemy == null || EnemyFieldEnemyParent == null)
                return null;

            return EnemyFieldEnemyParent.GetValue(enemy) as EnemyParent;
        }

        internal static PlayerAvatar GetSlowMouthTarget(EnemySlowMouth slowMouth)
        {
            if (slowMouth == null || EnemySlowMouthPlayerTargetField == null)
                return null;

            return EnemySlowMouthPlayerTargetField.GetValue(slowMouth) as PlayerAvatar;
        }

        internal static bool IsPlayerDisabled(PlayerAvatar playerAvatar)
        {
            if (playerAvatar == null || PlayerIsDisabledField == null)
                return false;

            object value = PlayerIsDisabledField.GetValue(playerAvatar);
            return value is bool disabled && disabled;
        }

        internal static int[] GetPlayerColorsEquipped(PlayerCosmetics cosmetics)
        {
            if (cosmetics == null || PlayerCosmeticsColorsEquippedField == null)
                return null;

            return PlayerCosmeticsColorsEquippedField.GetValue(cosmetics) as int[];
        }

        internal static float GetMouseWheel()
        {
            if (InputMouseScrollDeltaProperty == null)
                return 0f;

            object value = InputMouseScrollDeltaProperty.GetValue(null, null);
            return value is Vector2 scroll ? scroll.y : 0f;
        }

        internal static bool GetKeyDown(KeyCode keyCode)
        {
            if (InputGetKeyDownMethod == null)
                return false;

            object value = InputGetKeyDownMethod.Invoke(null, new object[] { keyCode });
            return value is bool pressed && pressed;
        }
    }
}
