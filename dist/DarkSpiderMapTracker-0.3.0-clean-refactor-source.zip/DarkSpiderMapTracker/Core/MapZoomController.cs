using System;
using UnityEngine;

namespace DarkSpider.MapTracker
{
    internal sealed class MapZoomController
    {
        private readonly PluginConfig _config;

        internal static Camera MapCamera { get; private set; }
        internal static float DefaultMapZoom { get; private set; }

        internal MapZoomController(PluginConfig config)
        {
            _config = config;
        }

        internal static void SetMapCamera(Camera camera)
        {
            MapCamera = camera;
            if (MapCamera != null)
                DefaultMapZoom = MapCamera.orthographicSize;
        }

        internal void CaptureDefaultZoom()
        {
            if (MapCamera != null && DefaultMapZoom <= 0f)
                DefaultMapZoom = MapCamera.orthographicSize;
        }

        internal void Tick()
        {
            if (!IsMapOpen())
                return;

            HandleInput();
            ApplyZoom();
        }

        internal void ResetZoom()
        {
            if (MapCamera != null && DefaultMapZoom > 0f)
                MapCamera.orthographicSize = DefaultMapZoom;
        }

        private void HandleInput()
        {
            ZoomInputMode inputMode = _config.ZoomInputMode.Value;
            if (inputMode == ZoomInputMode.Disabled)
                return;

            float value = _config.MapZoomMultiplier.Value;
            float step = Mathf.Clamp(_config.ZoomStep.Value, 0.05f, 1.0f);
            bool changed = false;

            if (inputMode == ZoomInputMode.MouseWheel || inputMode == ZoomInputMode.MouseWheelAndKeyboard)
            {
                float wheel = ReflectionCache.GetMouseWheel();
                if (Mathf.Abs(wheel) > 0.01f)
                {
                    value -= wheel * step;
                    changed = true;
                }
            }

            if (inputMode == ZoomInputMode.Keyboard || inputMode == ZoomInputMode.MouseWheelAndKeyboard)
            {
                if (IsConfiguredKeyDown(_config.ZoomInKey.Value))
                {
                    value -= step;
                    changed = true;
                }

                if (IsConfiguredKeyDown(_config.ZoomOutKey.Value))
                {
                    value += step;
                    changed = true;
                }
            }

            if (changed)
                _config.MapZoomMultiplier.Value = Mathf.Clamp(value, 0.25f, 5.0f);
        }

        private void ApplyZoom()
        {
            if (MapCamera == null || DefaultMapZoom <= 0f)
                return;

            MapCamera.orthographicSize = DefaultMapZoom * Mathf.Clamp(_config.MapZoomMultiplier.Value, 0.25f, 5.0f);
        }

        private static bool IsMapOpen()
        {
            if (Map.Instance != null && Map.Instance.Active)
                return true;

            return MapCamera != null && MapCamera.gameObject.activeInHierarchy && MapCamera.enabled;
        }

        private static bool IsConfiguredKeyDown(string keyName)
        {
            if (string.IsNullOrWhiteSpace(keyName))
                return false;

            string normalized = keyName.Trim();
            if (normalized == "+" || normalized == "=")
                normalized = "Equals";
            else if (normalized == "-" || normalized == "_")
                normalized = "Minus";
            else if (normalized.Equals("Plus", StringComparison.OrdinalIgnoreCase))
                normalized = "Equals";

            return Enum.TryParse(normalized, true, out KeyCode keyCode) && ReflectionCache.GetKeyDown(keyCode);
        }
    }
}
