using BepInEx.Configuration;
using UnityEngine;

namespace DarkSpider.MapTracker
{
    internal enum ArrowColorPreset
    {
        Red,
        Orange,
        Yellow,
        Green,
        Cyan,
        Blue,
        Purple,
        Pink,
        White,
        Black,
        Gray,
        CustomHex
    }

    internal enum PlayerArrowColorMode
    {
        PlayerHeadColor,
        Red,
        Orange,
        Yellow,
        Green,
        Cyan,
        Blue,
        Purple,
        Pink,
        White,
        Black,
        Gray,
        CustomHex
    }

    internal enum ZoomInputMode
    {
        MouseWheel,
        Keyboard,
        MouseWheelAndKeyboard,
        Disabled
    }

    internal sealed class PluginConfig
    {
        internal ConfigEntry<bool> ModEnabled { get; }
        internal ConfigEntry<bool> ShowEnemies { get; }
        internal ConfigEntry<ArrowColorPreset> EnemyColor { get; }
        internal ConfigEntry<string> EnemyCustomHex { get; }
        internal ConfigEntry<float> EnemyArrowScale { get; }

        internal ConfigEntry<bool> ShowPlayers { get; }
        internal ConfigEntry<PlayerArrowColorMode> PlayerColor { get; }
        internal ConfigEntry<string> PlayerCustomHex { get; }
        internal ConfigEntry<float> PlayerArrowScale { get; }

        internal ConfigEntry<bool> OutlineEnabled { get; }
        internal ConfigEntry<ArrowColorPreset> OutlineColor { get; }
        internal ConfigEntry<string> OutlineCustomHex { get; }
        internal ConfigEntry<float> OutlineScale { get; }

        internal ConfigEntry<float> MapZoomMultiplier { get; }
        internal ConfigEntry<ZoomInputMode> ZoomInputMode { get; }
        internal ConfigEntry<string> ZoomInKey { get; }
        internal ConfigEntry<string> ZoomOutKey { get; }
        internal ConfigEntry<float> ZoomStep { get; }

        internal PluginConfig(ConfigFile config)
        {
            ModEnabled = config.Bind("General", "ModEnabled", true, "Enable or disable the whole map tracker mod.");

            ShowEnemies = config.Bind("Enemies", "ShowEnemyArrows", true, "Show enemy arrows on the map.");
            EnemyColor = config.Bind("Enemies", "EnemyArrowColor", ArrowColorPreset.Red, "Enemy arrow color. Select CustomHex to use EnemyCustomHex.");
            EnemyCustomHex = config.Bind("Enemies", "EnemyCustomHex", "#FF0000", "Custom enemy arrow color used when EnemyArrowColor is CustomHex.");
            EnemyArrowScale = config.Bind("Enemies", "EnemyArrowScale", 0.25f, new ConfigDescription("Enemy arrow size. 0.25 is the original small triangle size.", new AcceptableValueRange<float>(0.25f, 3.0f)));

            ShowPlayers = config.Bind("Players", "ShowPlayerArrows", true, "Show player arrows on the map.");
            PlayerColor = config.Bind("Players", "PlayerArrowColor", PlayerArrowColorMode.PlayerHeadColor, "Player arrow color. PlayerHeadColor uses the player's HeadTopMesh color. Select CustomHex to use PlayerCustomHex.");
            PlayerCustomHex = config.Bind("Players", "PlayerCustomHex", "#00FFFF", "Custom player arrow color used when PlayerArrowColor is CustomHex.");
            PlayerArrowScale = config.Bind("Players", "PlayerArrowScale", 0.25f, new ConfigDescription("Player arrow size. 0.25 is the original small triangle size.", new AcceptableValueRange<float>(0.25f, 3.0f)));

            OutlineEnabled = config.Bind("Outline", "OutlineEnabled", true, "Draw an outline behind map arrows. Useful for white and gray player colors.");
            OutlineColor = config.Bind("Outline", "OutlineColor", ArrowColorPreset.Black, "Outline color. Select CustomHex to use OutlineCustomHex.");
            OutlineCustomHex = config.Bind("Outline", "OutlineCustomHex", "#000000", "Custom outline color used when OutlineColor is CustomHex.");
            OutlineScale = config.Bind("Outline", "OutlineScale", 1.35f, new ConfigDescription("Outline size relative to the main arrow.", new AcceptableValueRange<float>(1.0f, 2.0f)));

            MapZoomMultiplier = config.Bind("Map Zoom", "MapZoomMultiplier", 1.0f, new ConfigDescription("1.0 = vanilla. Bigger values zoom out, smaller values zoom in.", new AcceptableValueRange<float>(0.25f, 5.0f)));
            ZoomInputMode = config.Bind("Map Zoom", "ZoomInputMode", MapTracker.ZoomInputMode.MouseWheel, "How map zoom is controlled while the map is open.");
            ZoomInKey = config.Bind("Map Zoom", "ZoomInKey", "Equals", "Keyboard zoom-in key while the map is open. Examples: Equals, Plus, KeypadPlus, PageUp.");
            ZoomOutKey = config.Bind("Map Zoom", "ZoomOutKey", "Minus", "Keyboard zoom-out key while the map is open. Examples: Minus, KeypadMinus, PageDown.");
            ZoomStep = config.Bind("Map Zoom", "ZoomStep", 0.1f, new ConfigDescription("How much each mouse-wheel notch or hotkey press changes MapZoomMultiplier.", new AcceptableValueRange<float>(0.05f, 1.0f)));
        }

        internal Color GetEnemyColor()
        {
            return ColorResolver.GetPresetColor(EnemyColor.Value, EnemyCustomHex.Value, Color.red);
        }

        internal Color GetOutlineColor()
        {
            return ColorResolver.GetPresetColor(OutlineColor.Value, OutlineCustomHex.Value, Color.black);
        }
    }
}
