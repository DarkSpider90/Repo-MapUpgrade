using System;
using UnityEngine;

namespace DarkSpider.MapTracker
{
    internal static class ColorResolver
    {
        private const int HeadTopMeshColorSlot = 5;

        internal static Color GetPlayerColor(PlayerAvatar playerAvatar, PlayerArrowColorMode mode, string customHex)
        {
            if (mode == PlayerArrowColorMode.PlayerHeadColor)
                return TryGetPlayerHeadTopColor(playerAvatar) ?? Color.cyan;

            if (mode == PlayerArrowColorMode.CustomHex)
                return ParseColor(customHex, Color.cyan);

            return Enum.TryParse(mode.ToString(), out ArrowColorPreset preset)
                ? GetPresetColor(preset, customHex, Color.cyan)
                : Color.cyan;
        }

        internal static Color GetPresetColor(ArrowColorPreset preset, string customHex, Color fallback)
        {
            switch (preset)
            {
                case ArrowColorPreset.Red: return Color.red;
                case ArrowColorPreset.Orange: return new Color(1f, 0.5f, 0f, 1f);
                case ArrowColorPreset.Yellow: return Color.yellow;
                case ArrowColorPreset.Green: return Color.green;
                case ArrowColorPreset.Cyan: return Color.cyan;
                case ArrowColorPreset.Blue: return Color.blue;
                case ArrowColorPreset.Purple: return new Color(0.55f, 0f, 1f, 1f);
                case ArrowColorPreset.Pink: return new Color(1f, 0.1f, 0.65f, 1f);
                case ArrowColorPreset.White: return Color.white;
                case ArrowColorPreset.Black: return Color.black;
                case ArrowColorPreset.Gray: return Color.gray;
                case ArrowColorPreset.CustomHex: return ParseColor(customHex, fallback);
                default: return fallback;
            }
        }

        private static Color? TryGetPlayerHeadTopColor(PlayerAvatar playerAvatar)
        {
            try
            {
                PlayerCosmetics cosmetics = playerAvatar != null ? playerAvatar.playerCosmetics : null;
                int[] equippedColors = ReflectionCache.GetPlayerColorsEquipped(cosmetics);
                if (equippedColors == null || equippedColors.Length <= HeadTopMeshColorSlot)
                    return null;

                int colorIndex = equippedColors[HeadTopMeshColorSlot];

                if (MetaManager.instance == null || MetaManager.instance.colors == null || MetaManager.instance.colors.Count == 0)
                    return null;

                if (colorIndex < 0 || colorIndex >= MetaManager.instance.colors.Count)
                    colorIndex = 0;

                SemiColor semiColor = MetaManager.instance.colors[colorIndex];
                return semiColor != null ? semiColor.color : (Color?)null;
            }
            catch
            {
                return null;
            }
        }

        private static Color ParseColor(string htmlColor, Color fallback)
        {
            return !string.IsNullOrWhiteSpace(htmlColor) && ColorUtility.TryParseHtmlString(htmlColor.Trim(), out Color color)
                ? color
                : fallback;
        }
    }
}
