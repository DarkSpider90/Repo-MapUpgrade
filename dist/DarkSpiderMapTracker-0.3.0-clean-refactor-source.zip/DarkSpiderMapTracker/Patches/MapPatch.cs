using HarmonyLib;
using UnityEngine;

namespace DarkSpider.MapTracker.Patches
{
    [HarmonyPatch(typeof(Map))]
    internal static class MapPatch
    {
        [HarmonyPatch("Awake")]
        [HarmonyPostfix]
        private static void Awake(Map __instance, ref Transform ___playerTransformTarget)
        {
            if (___playerTransformTarget != null)
                MapZoomController.SetMapCamera(___playerTransformTarget.GetComponentInChildren<Camera>());

            Plugin.Instance?.OnMapAwake(__instance);
        }

        [HarmonyPatch("Update")]
        [HarmonyPostfix]
        private static void Update(Map __instance)
        {
            Plugin.Instance?.TickMap(__instance);
        }
    }
}
