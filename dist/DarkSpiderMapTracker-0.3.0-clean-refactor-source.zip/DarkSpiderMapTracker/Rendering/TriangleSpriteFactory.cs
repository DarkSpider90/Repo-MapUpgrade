using UnityEngine;

namespace DarkSpider.MapTracker
{
    internal static class TriangleSpriteFactory
    {
        internal static Sprite Create(string name, int size)
        {
            Texture2D texture = new Texture2D(size, size, TextureFormat.ARGB32, false)
            {
                name = name,
                wrapMode = TextureWrapMode.Clamp,
                filterMode = FilterMode.Bilinear
            };

            Color clear = new Color(1f, 1f, 1f, 0f);

            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                    texture.SetPixel(x, y, clear);
            }

            Vector2 tip = new Vector2(size * 0.5f, size * 0.88f);
            Vector2 left = new Vector2(size * 0.18f, size * 0.18f);
            Vector2 right = new Vector2(size * 0.82f, size * 0.18f);

            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    Vector2 point = new Vector2(x + 0.5f, y + 0.5f);
                    if (IsInsideTriangle(point, tip, right, left))
                        texture.SetPixel(x, y, Color.white);
                }
            }

            texture.Apply(false, true);
            return Sprite.Create(texture, new Rect(0f, 0f, size, size), new Vector2(0.5f, 0.5f), size);
        }

        private static bool IsInsideTriangle(Vector2 point, Vector2 a, Vector2 b, Vector2 c)
        {
            float denominator = (b.y - c.y) * (a.x - c.x) + (c.x - b.x) * (a.y - c.y);
            if (Mathf.Abs(denominator) < 0.0001f)
                return false;

            float alpha = ((b.y - c.y) * (point.x - c.x) + (c.x - b.x) * (point.y - c.y)) / denominator;
            float beta = ((c.y - a.y) * (point.x - c.x) + (a.x - c.x) * (point.y - c.y)) / denominator;
            float gamma = 1f - alpha - beta;

            return alpha >= 0f && beta >= 0f && gamma >= 0f;
        }
    }
}
