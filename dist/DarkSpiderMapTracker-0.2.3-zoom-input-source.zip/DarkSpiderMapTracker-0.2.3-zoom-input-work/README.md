# DarkSpider Map Tracker 0.2.2 test

Changes:
- Map zoom now supports mouse wheel while the map is open.
- Added `ZoomInputMode`: `MouseWheel`, `Keyboard`, `MouseWheelAndKeyboard`, `Disabled`.
- Keyboard hotkeys remain configurable with `ZoomInKey` and `ZoomOutKey`.

Recommended after update: delete old `BepInEx/config/DarkSpider90.MapTracker.cfg` once, so BepInEx writes the new config entries.
