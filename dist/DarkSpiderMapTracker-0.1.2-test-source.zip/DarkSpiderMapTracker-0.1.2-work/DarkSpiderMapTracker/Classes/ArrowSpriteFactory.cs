using UnityEngine;

namespace MapUpgrade.Classes
{
    internal static class ArrowSpriteFactory
    {
        internal static Sprite CreateArrowSprite(string name, int size)
        {
            Texture2D texture = new Texture2D(size, size, TextureFormat.ARGB32, false);
            texture.name = name;
            texture.wrapMode = TextureWrapMode.Clamp;
            texture.filterMode = FilterMode.Bilinear;

            Color clear = new Color(1f, 1f, 1f, 0f);
            Color white = Color.white;

            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                    texture.SetPixel(x, y, clear);
            }

            // Top-down map arrow. It points toward +Z/up in texture space.
            Vector2 tip = new Vector2(size * 0.5f, size * 0.08f);
            Vector2 leftWing = new Vector2(size * 0.14f, size * 0.58f);
            Vector2 innerLeft = new Vector2(size * 0.39f, size * 0.49f);
            Vector2 tailLeft = new Vector2(size * 0.39f, size * 0.92f);
            Vector2 tailRight = new Vector2(size * 0.61f, size * 0.92f);
            Vector2 innerRight = new Vector2(size * 0.61f, size * 0.49f);
            Vector2 rightWing = new Vector2(size * 0.86f, size * 0.58f);

            Vector2[] polygon = new[] { tip, rightWing, innerRight, tailRight, tailLeft, innerLeft, leftWing };

            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    Vector2 p = new Vector2(x + 0.5f, y + 0.5f);
                    if (PointInPolygon(p, polygon))
                        texture.SetPixel(x, y, white);
                }
            }

            texture.Apply(false, true);
            return Sprite.Create(texture, new Rect(0f, 0f, size, size), new Vector2(0.5f, 0.5f), size);
        }

        private static bool PointInPolygon(Vector2 point, Vector2[] polygon)
        {
            bool inside = false;
            int j = polygon.Length - 1;
            for (int i = 0; i < polygon.Length; i++)
            {
                if ((polygon[i].y > point.y) != (polygon[j].y > point.y) &&
                    point.x < (polygon[j].x - polygon[i].x) * (point.y - polygon[i].y) / (polygon[j].y - polygon[i].y) + polygon[i].x)
                {
                    inside = !inside;
                }
                j = i;
            }
            return inside;
        }
    }
}
