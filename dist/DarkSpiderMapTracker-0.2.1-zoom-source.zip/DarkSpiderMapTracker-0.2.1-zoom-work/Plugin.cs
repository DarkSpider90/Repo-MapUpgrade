using BepInEx;
using BepInEx.Configuration;
using HarmonyLib;
using MapUpgrade.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using UnityEngine;

namespace MapUpgrade
{
    [BepInPlugin(ModGuid, ModName, ModVersion)]
    internal sealed class Plugin : BaseUnityPlugin
    {
        private const string ModGuid = "DarkSpider90.MapTracker";
        private const string ModName = "DarkSpider Map Tracker";
        private const string ModVersion = "0.2.1";

        internal static Plugin Instance;

        private readonly Harmony _harmony = new Harmony(ModGuid);
        private readonly List<MapInfo> _enemyMapInfos = new List<MapInfo>();
        private readonly List<MapInfo> _playerMapInfos = new List<MapInfo>();

        private ConfigEntry<bool> _modEnabled;
        private ConfigEntry<bool> _showEnemies;
        private ConfigEntry<ColorPreset> _enemyColor;
        private ConfigEntry<string> _enemyCustomHex;
        private ConfigEntry<bool> _showPlayers;
        private ConfigEntry<PlayerColorMode> _playerColor;
        private ConfigEntry<string> _playerCustomHex;
        private ConfigEntry<bool> _outlineEnabled;
        private ConfigEntry<ColorPreset> _outlineColor;
        private ConfigEntry<string> _outlineCustomHex;
        private ConfigEntry<float> _enemyArrowScale;
        private ConfigEntry<float> _playerArrowScale;
        private ConfigEntry<float> _mapZoomMultiplier;
        private ConfigEntry<ZoomInputMode> _zoomInputMode;
        private ConfigEntry<KeyboardShortcut> _zoomInKey;
        private ConfigEntry<KeyboardShortcut> _zoomOutKey;
        private ConfigEntry<float> _zoomStep;

        private Sprite _arrowSprite;
        private float _nextSafetyScan;
        private Map _lastMap;

        private const float SafetyScanInterval = 1.0f;
        private const float OutlineScale = 1.35f;

        private static readonly FieldInfo EnemyParentEnemyField = AccessTools.Field(typeof(EnemyParent), "Enemy");
        private static readonly FieldInfo PlayerCosmeticsField = AccessTools.Field(typeof(PlayerAvatar), "playerCosmetics");
        private static readonly FieldInfo PlayerCosmeticsColorsEquippedField = AccessTools.Field(typeof(PlayerCosmetics), "colorsEquipped");
        private static readonly FieldInfo MetaManagerInstanceField = AccessTools.Field(typeof(MetaManager), "instance");
        private static readonly FieldInfo MetaManagerColorsField = AccessTools.Field(typeof(MetaManager), "colors");
        private static readonly FieldInfo SemiColorColorField = AccessTools.Field(typeof(SemiColor), "color");

        private enum ColorPreset
        {
            Red,
            Orange,
            Yellow,
            Green,
            Cyan,
            Blue,
            Purple,
            Pink,
            White,
            Black,
            Gray,
            CustomHex
        }

        private enum PlayerColorMode
        {
            PlayerHeadColor,
            Red,
            Orange,
            Yellow,
            Green,
            Cyan,
            Blue,
            Purple,
            Pink,
            White,
            Black,
            Gray,
            CustomHex
        }

        private enum ZoomInputMode
        {
            MouseWheel,
            Keyboard,
            MouseWheelAndKeyboard,
            Disabled
        }

        private void Awake()
        {
            Instance = this;

            _modEnabled = Config.Bind("General", "ModEnabled", true, "Enable or disable the whole map tracker mod.");

            _showEnemies = Config.Bind("Enemies", "ShowEnemyArrows", true, "Show enemy arrows on the map.");
            _enemyColor = Config.Bind("Enemies", "EnemyArrowColor", ColorPreset.Red, "Enemy arrow color. Select CustomHex to use EnemyCustomHex.");
            _enemyCustomHex = Config.Bind("Enemies", "EnemyCustomHex", "#FF0000", "Custom enemy arrow color used when EnemyArrowColor is CustomHex.");
            _enemyArrowScale = Config.Bind("Enemies", "EnemyArrowScale", 0.25f, new ConfigDescription("Enemy arrow size. 0.25 is the original small triangle size.", new AcceptableValueRange<float>(0.25f, 3.0f)));

            _showPlayers = Config.Bind("Players", "ShowPlayerArrows", true, "Show player arrows on the map.");
            _playerColor = Config.Bind("Players", "PlayerArrowColor", PlayerColorMode.PlayerHeadColor, "Player arrow color. PlayerHeadColor uses the player's equipped color. Select CustomHex to use PlayerCustomHex.");
            _playerCustomHex = Config.Bind("Players", "PlayerCustomHex", "#00FFFF", "Custom player arrow color used when PlayerArrowColor is CustomHex.");
            _playerArrowScale = Config.Bind("Players", "PlayerArrowScale", 0.25f, new ConfigDescription("Player arrow size. 0.25 is the original small triangle size.", new AcceptableValueRange<float>(0.25f, 3.0f)));

            _outlineEnabled = Config.Bind("Outline", "OutlineEnabled", false, "Draw a black/color outline behind map arrows.");
            _outlineColor = Config.Bind("Outline", "OutlineColor", ColorPreset.Black, "Outline color. Select CustomHex to use OutlineCustomHex.");
            _outlineCustomHex = Config.Bind("Outline", "OutlineCustomHex", "#000000", "Custom outline color used when OutlineColor is CustomHex.");

            _mapZoomMultiplier = Config.Bind("Map Zoom", "MapZoomMultiplier", 1.0f, new ConfigDescription("1.0 = vanilla. Bigger values zoom out, smaller values zoom in.", new AcceptableValueRange<float>(0.25f, 5.0f)));
            _zoomInputMode = Config.Bind("Map Zoom", "ZoomInputMode", ZoomInputMode.MouseWheel, "How map zoom is controlled while the map is open. MouseWheel = mouse wheel only. Keyboard = hotkeys only. MouseWheelAndKeyboard = both. Disabled = only MapZoomMultiplier is used.");
            _zoomInKey = Config.Bind("Map Zoom", "ZoomInKey", new KeyboardShortcut(KeyCode.Equals), "Keyboard zoom-in hotkey while the map is open. Default: Equals key (= / +).");
            _zoomOutKey = Config.Bind("Map Zoom", "ZoomOutKey", new KeyboardShortcut(KeyCode.Minus), "Keyboard zoom-out hotkey while the map is open. Default: Minus key (- / _).");
            _zoomStep = Config.Bind("Map Zoom", "ZoomStep", 0.1f, new ConfigDescription("How much each mouse-wheel notch or hotkey press changes MapZoomMultiplier.", new AcceptableValueRange<float>(0.05f, 1.0f)));

            _arrowSprite = ArrowSpriteFactory.CreateTriangleSprite("DarkSpiderMapTracker.Triangle", 64);
            _harmony.PatchAll(Assembly.GetExecutingAssembly());
            Logger.LogInfo($"{ModName} {ModVersion} loaded.");
        }

        internal void OnMapAwake(Map map)
        {
            if (map == null)
                return;

            _lastMap = map;
            ClearMapInfos();
            _nextSafetyScan = 0f;
        }

        internal void TickMap(Map map)
        {
            if (map == null || Map.Instance == null)
                return;

            if (_lastMap != map)
                OnMapAwake(map);

            if (!_modEnabled.Value)
            {
                SetAllRenderersEnabled(false);
                ResetMapZoom();
                return;
            }

            HandleZoomHotkeys();
            ApplyMapZoom();

            if (Time.time >= _nextSafetyScan)
            {
                _nextSafetyScan = Time.time + SafetyScanInterval;
                SafetyScanExistingObjects();
            }

            UpdateTracker(_enemyMapInfos, false);
            UpdateTracker(_playerMapInfos, true);
        }

        private void HandleZoomHotkeys()
        {
            if (!IsMapOpen())
                return;

            ZoomInputMode inputMode = _zoomInputMode.Value;
            if (inputMode == ZoomInputMode.Disabled)
                return;

            float value = _mapZoomMultiplier.Value;
            float step = Mathf.Clamp(_zoomStep.Value, 0.05f, 1.0f);
            bool changed = false;

            if (inputMode == ZoomInputMode.MouseWheel || inputMode == ZoomInputMode.MouseWheelAndKeyboard)
            {
                float wheel = Input.mouseScrollDelta.y;
                if (Mathf.Abs(wheel) > 0.01f)
                {
                    value -= wheel * step;
                    changed = true;
                }
            }

            if (inputMode == ZoomInputMode.Keyboard || inputMode == ZoomInputMode.MouseWheelAndKeyboard)
            {
                if (_zoomInKey.Value.IsDown())
                {
                    value -= step;
                    changed = true;
                }

                if (_zoomOutKey.Value.IsDown())
                {
                    value += step;
                    changed = true;
                }
            }

            if (changed)
                _mapZoomMultiplier.Value = Mathf.Clamp(value, 0.25f, 5.0f);
        }

        private static bool IsMapOpen()
        {
            if (Map.Instance != null && Map.Instance.Active)
                return true;

            Camera mapCamera = Patches.MapPatch.MapCamera;
            return mapCamera != null && mapCamera.gameObject.activeInHierarchy && mapCamera.enabled;
        }

        private void ApplyMapZoom()
        {
            if (Patches.MapPatch.MapCamera == null || Patches.MapPatch.DefaultMapZoom <= 0f)
                return;

            Patches.MapPatch.MapCamera.orthographicSize = Patches.MapPatch.DefaultMapZoom * Mathf.Clamp(_mapZoomMultiplier.Value, 0.25f, 5.0f);
        }

        private static void ResetMapZoom()
        {
            if (Patches.MapPatch.MapCamera == null || Patches.MapPatch.DefaultMapZoom <= 0f)
                return;

            Patches.MapPatch.MapCamera.orthographicSize = Patches.MapPatch.DefaultMapZoom;
        }

        private void SafetyScanExistingObjects()
        {
            if (Map.Instance == null)
                return;

            if (_showEnemies.Value)
            {
                foreach (EnemyParent enemyParent in FindObjectsOfType<EnemyParent>())
                    RegisterToMap(enemyParent);
            }

            if (_showPlayers.Value)
            {
                foreach (PlayerAvatar playerAvatar in FindObjectsOfType<PlayerAvatar>())
                {
                    if (playerAvatar != null && playerAvatar != PlayerController.instance?.playerAvatarScript)
                    {
                        RegisterToMap(playerAvatar);
                        ShowToMap(playerAvatar);
                    }
                }
            }
        }

        private GameObject GetVisualsFromComponent(Component component)
        {
            if (component is PlayerAvatar playerAvatar)
                return playerAvatar.playerAvatarVisuals != null ? playerAvatar.playerAvatarVisuals.gameObject : playerAvatar.gameObject;

            if (!(component is EnemyParent enemyParent))
                return null;

            Enemy enemy = TryGetEnemy(enemyParent);
            GameObject visuals = null;

            if (enemyParent.enemyName != "Bella")
            {
                visuals = TryGetVisionObject(enemyParent);
                if (visuals == null)
                    visuals = GetFirstComponentGameObject(enemyParent.EnableObject, "UnityEngine.Animator");
            }
            else if (enemy != null)
            {
                visuals = TryGetTricycleTargetObject(enemy);
            }

            if (visuals == null && enemy != null)
                visuals = enemy.gameObject;

            return visuals != null ? visuals : enemyParent.gameObject;
        }

        private Enemy TryGetEnemy(EnemyParent enemyParent)
        {
            if (enemyParent == null || EnemyParentEnemyField == null)
                return null;

            try
            {
                return EnemyParentEnemyField.GetValue(enemyParent) as Enemy;
            }
            catch (Exception exception)
            {
                Logger.LogDebug($"Failed to read EnemyParent.Enemy: {exception.Message}");
                return null;
            }
        }

        private GameObject TryGetVisionObject(EnemyParent enemyParent)
        {
            try
            {
                EnemyVision vision = enemyParent.GetComponentInChildren<EnemyVision>();
                return vision?.VisionTransform != null ? vision.VisionTransform.gameObject : null;
            }
            catch (Exception exception)
            {
                Logger.LogDebug($"Failed to read enemy vision transform: {exception.Message}");
                return null;
            }
        }

        private GameObject TryGetTricycleTargetObject(Enemy enemy)
        {
            try
            {
                EnemyTricycle tricycle = enemy.GetComponentInChildren<EnemyTricycle>();
                return tricycle?.followTargetTransform != null ? tricycle.followTargetTransform.gameObject : null;
            }
            catch (Exception exception)
            {
                Logger.LogDebug($"Failed to read EnemyTricycle target: {exception.Message}");
                return null;
            }
        }

        private static GameObject GetFirstComponentGameObject(GameObject rootObject, string componentTypeName)
        {
            if (rootObject == null || string.IsNullOrEmpty(componentTypeName))
                return null;

            Component[] components = rootObject.GetComponentsInChildren<Component>(true);
            for (int i = 0; i < components.Length; i++)
            {
                Component component = components[i];
                if (component == null)
                    continue;

                Type type = component.GetType();
                if (type.FullName == componentTypeName || type.Name == componentTypeName)
                    return component.gameObject;
            }

            return null;
        }

        internal void RegisterToMap(Component component)
        {
            if (!_modEnabled.Value || Map.Instance == null || Map.Instance.CustomObject == null || Map.Instance.OverLayerParent == null || component == null)
                return;

            bool isEnemy = component is EnemyParent;
            bool isPlayer = component is PlayerAvatar;
            if ((!isEnemy || !_showEnemies.Value) && (!isPlayer || !_showPlayers.Value))
                return;

            List<MapInfo> list = isPlayer ? _playerMapInfos : _enemyMapInfos;
            if (list.Any(x => x.Component == component))
                return;

            GameObject visuals = GetVisualsFromComponent(component);
            if (visuals == null)
                return;

            GameObject mapObject = Instantiate(Map.Instance.CustomObject, Map.Instance.OverLayerParent);
            mapObject.name = "DarkSpider Map Tracker - " + visuals.name;

            MapCustomEntity mapCustomEntity = mapObject.GetComponent<MapCustomEntity>();
            if (mapCustomEntity == null)
            {
                Destroy(mapObject);
                return;
            }

            mapCustomEntity.Parent = visuals.transform;
            SpriteRenderer spriteRenderer = mapCustomEntity.spriteRenderer != null ? mapCustomEntity.spriteRenderer : mapObject.GetComponentInChildren<SpriteRenderer>(true);
            if (spriteRenderer == null)
            {
                Destroy(mapObject);
                return;
            }

            spriteRenderer.sprite = _arrowSprite;
            spriteRenderer.enabled = false;

            SpriteRenderer outlineRenderer = CreateOutlineRenderer(spriteRenderer);

            list.Add(new MapInfo
            {
                Component = component,
                MapCustomEntity = mapCustomEntity,
                SpriteRenderer = spriteRenderer,
                OutlineRenderer = outlineRenderer,
                Visible = false
            });
        }

        private SpriteRenderer CreateOutlineRenderer(SpriteRenderer mainRenderer)
        {
            GameObject outlineObject = new GameObject("Arrow Outline");
            Transform parent = mainRenderer.transform.parent != null ? mainRenderer.transform.parent : mainRenderer.transform;
            outlineObject.transform.SetParent(parent, false);
            outlineObject.transform.localPosition = mainRenderer.transform.localPosition;
            outlineObject.transform.localRotation = mainRenderer.transform.localRotation;
            outlineObject.transform.localScale = Vector3.one;

            SpriteRenderer outlineRenderer = outlineObject.AddComponent<SpriteRenderer>();
            outlineRenderer.sprite = _arrowSprite;
            outlineRenderer.color = GetColor(_outlineColor.Value, _outlineCustomHex.Value, Color.black);
            outlineRenderer.sortingLayerID = mainRenderer.sortingLayerID;
            outlineRenderer.sortingOrder = mainRenderer.sortingOrder - 1;
            outlineRenderer.enabled = false;
            return outlineRenderer;
        }

        internal void ShowToMap(Component component)
        {
            MapInfo mapInfo = FindMapInfo(component);
            if (mapInfo != null)
                mapInfo.Visible = true;
        }

        internal void HideFromMap(Component component)
        {
            MapInfo mapInfo = FindMapInfo(component);
            if (mapInfo != null)
                mapInfo.Visible = false;
        }

        internal void SwapOnMap(Component component, Component fromComponent)
        {
            MapInfo mapInfo = FindMapInfo(component);
            MapInfo fromMapInfo = FindMapInfo(fromComponent);
            if (mapInfo == null || fromMapInfo == null)
                return;

            bool mapInfoIsEnemy = _enemyMapInfos.Contains(mapInfo);
            bool fromMapInfoIsEnemy = _enemyMapInfos.Contains(fromMapInfo);
            if (mapInfoIsEnemy == fromMapInfoIsEnemy)
                return;

            if (mapInfoIsEnemy)
            {
                _enemyMapInfos.Remove(mapInfo);
                _enemyMapInfos.Add(fromMapInfo);
                _playerMapInfos.Remove(fromMapInfo);
                _playerMapInfos.Add(mapInfo);
            }
            else
            {
                _playerMapInfos.Remove(mapInfo);
                _playerMapInfos.Add(fromMapInfo);
                _enemyMapInfos.Remove(fromMapInfo);
                _enemyMapInfos.Add(mapInfo);
            }
        }

        private MapInfo FindMapInfo(Component component)
        {
            if (component == null)
                return null;

            return _enemyMapInfos.FirstOrDefault(x => x.Component == component) ??
                   _playerMapInfos.FirstOrDefault(x => x.Component == component);
        }

        private void UpdateTracker(List<MapInfo> mapInfos, bool playerTracker)
        {
            if (Map.Instance == null)
                return;

            bool enabledByConfig = playerTracker ? _showPlayers.Value : _showEnemies.Value;

            for (int i = mapInfos.Count - 1; i >= 0; i--)
            {
                MapInfo mapInfo = mapInfos[i];
                if (mapInfo == null || mapInfo.Component == null || mapInfo.MapCustomEntity == null || mapInfo.SpriteRenderer == null)
                {
                    mapInfos.RemoveAt(i);
                    continue;
                }

                SpriteRenderer spriteRenderer = mapInfo.SpriteRenderer;
                SpriteRenderer outlineRenderer = mapInfo.OutlineRenderer;
                Transform parent = mapInfo.MapCustomEntity.Parent;
                if (parent == null)
                {
                    SetRendererPairEnabled(spriteRenderer, outlineRenderer, false);
                    continue;
                }

                if (Map.Instance.Active)
                    Map.Instance.CustomPositionSet(mapInfo.MapCustomEntity.transform, parent);

                Color color = playerTracker ? GetPlayerArrowColor(mapInfo.Component as PlayerAvatar) : GetColor(_enemyColor.Value, _enemyCustomHex.Value, Color.red);
                float scale = playerTracker ? _playerArrowScale.Value : _enemyArrowScale.Value;
                float clampedScale = Mathf.Clamp(scale, 0.25f, 3.0f);

                spriteRenderer.sprite = _arrowSprite;
                spriteRenderer.color = color;
                spriteRenderer.transform.localScale = Vector3.one * clampedScale;
                spriteRenderer.enabled = enabledByConfig && mapInfo.Visible;

                if (outlineRenderer != null)
                {
                    Color outlineColor = GetColor(_outlineColor.Value, _outlineCustomHex.Value, Color.black);
                    outlineColor.a = color.a;
                    outlineRenderer.sprite = _arrowSprite;
                    outlineRenderer.color = outlineColor;
                    outlineRenderer.transform.localScale = Vector3.one * clampedScale * OutlineScale;
                    outlineRenderer.enabled = _outlineEnabled.Value && enabledByConfig && mapInfo.Visible;
                }
            }
        }

        private Color GetPlayerArrowColor(PlayerAvatar playerAvatar)
        {
            if (_playerColor.Value == PlayerColorMode.PlayerHeadColor && playerAvatar != null)
            {
                Color? cosmeticsColor = TryGetPlayerCosmeticsColor(playerAvatar);
                if (cosmeticsColor.HasValue)
                    return cosmeticsColor.Value;
            }

            if (_playerColor.Value == PlayerColorMode.CustomHex)
                return ParseColor(_playerCustomHex.Value, Color.cyan);

            return GetColor((ColorPreset)Enum.Parse(typeof(ColorPreset), _playerColor.Value.ToString()), _playerCustomHex.Value, Color.cyan);
        }

        private Color? TryGetPlayerCosmeticsColor(PlayerAvatar playerAvatar)
        {
            try
            {
                PlayerCosmetics cosmetics = PlayerCosmeticsField?.GetValue(playerAvatar) as PlayerCosmetics;
                int[] equippedColors = PlayerCosmeticsColorsEquippedField?.GetValue(cosmetics) as int[];
                MetaManager metaManager = MetaManagerInstanceField?.GetValue(null) as MetaManager;
                List<SemiColor> metaColors = MetaManagerColorsField?.GetValue(metaManager) as List<SemiColor>;

                if (equippedColors == null || metaColors == null)
                    return null;

                for (int i = 0; i < equippedColors.Length; i++)
                {
                    int colorIndex = equippedColors[i];
                    if (colorIndex < 0 || colorIndex >= metaColors.Count || metaColors[colorIndex] == null)
                        continue;

                    object value = SemiColorColorField?.GetValue(metaColors[colorIndex]);
                    if (value is Color color)
                        return color;
                }
            }
            catch (Exception exception)
            {
                Logger.LogDebug($"Failed to read player cosmetics color: {exception.Message}");
            }

            return null;
        }

        private static Color GetColor(ColorPreset preset, string customHex, Color fallback)
        {
            switch (preset)
            {
                case ColorPreset.Red: return Color.red;
                case ColorPreset.Orange: return new Color(1f, 0.5f, 0f, 1f);
                case ColorPreset.Yellow: return Color.yellow;
                case ColorPreset.Green: return Color.green;
                case ColorPreset.Cyan: return Color.cyan;
                case ColorPreset.Blue: return Color.blue;
                case ColorPreset.Purple: return new Color(0.55f, 0f, 1f, 1f);
                case ColorPreset.Pink: return new Color(1f, 0.1f, 0.65f, 1f);
                case ColorPreset.White: return Color.white;
                case ColorPreset.Black: return Color.black;
                case ColorPreset.Gray: return Color.gray;
                case ColorPreset.CustomHex: return ParseColor(customHex, fallback);
                default: return fallback;
            }
        }

        private static Color ParseColor(string htmlColor, Color fallback)
        {
            if (!string.IsNullOrWhiteSpace(htmlColor) && ColorUtility.TryParseHtmlString(htmlColor.Trim(), out Color color))
                return color;

            return fallback;
        }

        private void SetAllRenderersEnabled(bool enabled)
        {
            SetRenderersEnabled(_enemyMapInfos, enabled);
            SetRenderersEnabled(_playerMapInfos, enabled);
        }

        private static void SetRenderersEnabled(List<MapInfo> mapInfos, bool enabled)
        {
            foreach (MapInfo mapInfo in mapInfos)
            {
                if (mapInfo?.SpriteRenderer != null)
                    mapInfo.SpriteRenderer.enabled = enabled;
                if (mapInfo?.OutlineRenderer != null)
                    mapInfo.OutlineRenderer.enabled = enabled;
            }
        }

        private static void SetRendererPairEnabled(SpriteRenderer spriteRenderer, SpriteRenderer outlineRenderer, bool enabled)
        {
            if (spriteRenderer != null)
                spriteRenderer.enabled = enabled;
            if (outlineRenderer != null)
                outlineRenderer.enabled = enabled;
        }

        private void ClearMapInfos()
        {
            DestroyMapObjects(_enemyMapInfos);
            DestroyMapObjects(_playerMapInfos);
            _enemyMapInfos.Clear();
            _playerMapInfos.Clear();
        }

        private void DestroyMapObjects(List<MapInfo> mapInfos)
        {
            foreach (MapInfo mapInfo in mapInfos)
            {
                if (mapInfo?.MapCustomEntity != null)
                    Destroy(mapInfo.MapCustomEntity.gameObject);
            }
        }
    }
}
