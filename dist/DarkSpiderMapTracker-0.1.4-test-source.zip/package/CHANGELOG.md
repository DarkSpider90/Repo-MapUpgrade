# 0.1.4

- Use the original MoreUpgrades `Map Tracker` triangle sprite from the embedded asset bundle.
- Default arrow scale is now 1.0, matching MoreUpgrades.
- Outline disabled by default for the original clean triangle look.

# 0.1.4

- First test source build.
- Added standalone player/enemy map arrows.
- Added configurable player/enemy colors.
- Added player head color mode.
- Added black arrow outline.
- Added map zoom multiplier.
