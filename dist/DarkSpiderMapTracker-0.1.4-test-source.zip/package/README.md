# DarkSpider Map Tracker

Standalone configurable map tracker for R.E.P.O.

Shows players and enemies on the map as arrows.

## Config

Generated file:

```text
BepInEx/config/DarkSpider90.MapTracker.cfg
```

Main options:

- `ShowPlayers`
- `ShowEnemies`
- `UsePlayerHeadColor`
- `PlayerColor`
- `EnemyColor`
- `OutlineEnabled`
- `OutlineColor`
- `PlayerArrowScale`
- `EnemyArrowScale`
- `MapZoomMultiplier`
- `ExcludeEnemies`

