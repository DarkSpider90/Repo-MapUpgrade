using UnityEngine;

namespace MapUpgrade.Classes
{
    internal sealed class MapInfo
    {
        public Component Component;
        public MapCustomEntity MapCustomEntity;
        public SpriteRenderer SpriteRenderer;
        public SpriteRenderer OutlineRenderer;
        public bool Visible;
        public bool IsPlayer;
    }
}
