using BepInEx;
using BepInEx.Configuration;
using MapUpgrade.Classes;
using HarmonyLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using UnityEngine;

namespace MapUpgrade
{
    [BepInPlugin(ModGuid, ModName, ModVersion)]
    internal sealed class Plugin : BaseUnityPlugin
    {
        private const string ModGuid = "DarkSpider90.MapTracker";
        private const string ModName = "DarkSpider Map Tracker";
        private const string ModVersion = "0.1.4";

        internal static Plugin Instance;

        private readonly Harmony _harmony = new Harmony(ModGuid);

        internal ConfigEntry<bool> ShowPlayers;
        internal ConfigEntry<bool> ShowEnemies;
        internal ConfigEntry<bool> UsePlayerHeadColor;
        internal ConfigEntry<string> PlayerColor;
        internal ConfigEntry<string> EnemyColor;
        internal ConfigEntry<string> OutlineColor;
        internal ConfigEntry<bool> OutlineEnabled;
        internal ConfigEntry<float> PlayerArrowScale;
        internal ConfigEntry<float> EnemyArrowScale;
        internal ConfigEntry<float> OutlineScale;
        internal ConfigEntry<float> OtherFloorAlpha;
        internal ConfigEntry<float> TrackerRefreshRate;
        internal ConfigEntry<float> MapZoomMultiplier;
        internal ConfigEntry<string> ExcludeEnemies;

        private readonly List<MapInfo> _enemyMapInfos = new List<MapInfo>();
        private readonly List<MapInfo> _playerMapInfos = new List<MapInfo>();

        private Sprite _arrowSprite;
        private AssetBundle _assetBundle;
        private float _nextTrackerUpdate;
        private float _nextSafetyScan;
        private Map _lastMap;

        private static readonly FieldInfo EnemyParentEnemyField = AccessTools.Field(typeof(EnemyParent), "Enemy");
        private static readonly FieldInfo PlayerCosmeticsField = AccessTools.Field(typeof(PlayerAvatar), "playerCosmetics");
        private static readonly FieldInfo PlayerCosmeticsColorsEquippedField = AccessTools.Field(typeof(PlayerCosmetics), "colorsEquipped");
        private static readonly FieldInfo MetaManagerInstanceField = AccessTools.Field(typeof(MetaManager), "instance");
        private static readonly FieldInfo MetaManagerColorsField = AccessTools.Field(typeof(MetaManager), "colors");
        private static readonly FieldInfo SemiColorColorField = AccessTools.Field(typeof(SemiColor), "color");

        private void Awake()
        {
            Instance = this;
            ShowPlayers = Config.Bind("Players", "ShowPlayers", true, "Show player arrows on the map.");
            ShowEnemies = Config.Bind("Enemies", "ShowEnemies", true, "Show enemy arrows on the map.");
            UsePlayerHeadColor = Config.Bind("Players", "UsePlayerHeadColor", true, "If true, player arrows use the player's head/body color. If false, PlayerColor is used.");
            PlayerColor = Config.Bind("Players", "PlayerColor", "#00FFFF", "Fallback/custom player arrow color. Use a hex color, for example #00FFFF.");
            EnemyColor = Config.Bind("Enemies", "EnemyColor", "#FF0000", "Enemy arrow color. Use a hex color, for example #FF0000 or #FF0000FF.");
            ExcludeEnemies = Config.Bind("Enemies", "ExcludeEnemies", "", "Enemy names to hide, separated by commas. Example: Gnome, Clown");

            OutlineEnabled = Config.Bind("Style", "OutlineEnabled", false, "Draw a thin black outline behind every arrow. Disabled by default in the test build to keep the original MoreUpgrades look.");
            OutlineColor = Config.Bind("Style", "OutlineColor", "#000000", "Outline color. Use a hex color, for example #000000 or #000000FF.");
            PlayerArrowScale = Config.Bind("Style", "PlayerArrowScale", 1.0f, new ConfigDescription("Player arrow scale multiplier. 1.0 keeps the original MoreUpgrades tracker size.", new AcceptableValueRange<float>(0.25f, 3.0f)));
            EnemyArrowScale = Config.Bind("Style", "EnemyArrowScale", 1.0f, new ConfigDescription("Enemy arrow scale multiplier. 1.0 keeps the original MoreUpgrades tracker size.", new AcceptableValueRange<float>(0.25f, 3.0f)));
            OutlineScale = Config.Bind("Style", "OutlineScale", 1.12f, new ConfigDescription("Outline size relative to the main arrow.", new AcceptableValueRange<float>(1.0f, 1.5f)));
            OtherFloorAlpha = Config.Bind("Style", "OtherFloorAlpha", 0.3f, new ConfigDescription("Arrow opacity when target is on another map floor.", new AcceptableValueRange<float>(0.05f, 1.0f)));

            TrackerRefreshRate = Config.Bind("Performance", "TrackerRefreshRate", 0.2f, new ConfigDescription("Seconds between marker position/color refreshes.", new AcceptableValueRange<float>(0.03f, 2.0f)));
            MapZoomMultiplier = Config.Bind("Map", "MapZoomMultiplier", 1.0f, new ConfigDescription("1.0 = vanilla zoom. Bigger values zoom out, smaller values zoom in.", new AcceptableValueRange<float>(0.25f, 5.0f)));

            _arrowSprite = LoadOriginalMoreUpgradesArrowSprite() ?? ArrowSpriteFactory.CreateTriangleSprite("DarkSpiderMapTracker.FallbackTriangle", 64);
            _harmony.PatchAll(Assembly.GetExecutingAssembly());
            Logger.LogInfo($"{ModName} {ModVersion} loaded. Arrow sprite: {_arrowSprite?.name ?? "null"}");
        }

        private Sprite LoadOriginalMoreUpgradesArrowSprite()
        {
            try
            {
                using (System.IO.Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("MapUpgrade.Resources.moreupgrades"))
                {
                    if (stream == null)
                    {
                        Logger.LogWarning("Embedded MoreUpgrades asset bundle was not found. Falling back to generated triangle sprite.");
                        return null;
                    }

                    byte[] bytes = new byte[stream.Length];
                    int offset = 0;
                    while (offset < bytes.Length)
                    {
                        int read = stream.Read(bytes, offset, bytes.Length - offset);
                        if (read <= 0)
                            break;
                        offset += read;
                    }

                    _assetBundle = AssetBundle.LoadFromMemory(bytes);
                    if (_assetBundle == null)
                    {
                        Logger.LogWarning("Failed to load embedded MoreUpgrades asset bundle. Falling back to generated triangle sprite.");
                        return null;
                    }

                    Sprite sprite = _assetBundle.LoadAsset<Sprite>("Map Tracker");
                    if (sprite == null)
                        Logger.LogWarning("Asset 'Map Tracker' was not found in embedded bundle. Falling back to generated triangle sprite.");
                    return sprite;
                }
            }
            catch (Exception exception)
            {
                Logger.LogWarning($"Failed to load original MoreUpgrades arrow sprite: {exception.Message}");
                return null;
            }
        }

        internal void OnMapAwake(Map map)
        {
            if (map == null)
                return;

            _lastMap = map;
            ClearMapInfos();
            _nextSafetyScan = 0f;
        }

        internal void TickMap(Map map)
        {
            if (map == null || Map.Instance == null)
                return;

            if (_lastMap != map)
                OnMapAwake(map);

            ApplyMapZoom();

            if (Time.time >= _nextSafetyScan)
            {
                _nextSafetyScan = Time.time + 1.0f;
                SafetyScanExistingObjects();
            }

            if (Time.time < _nextTrackerUpdate)
                return;

            _nextTrackerUpdate = Time.time + Mathf.Max(0.03f, TrackerRefreshRate.Value);
            UpdateTracker(_enemyMapInfos, false);
            UpdateTracker(_playerMapInfos, true);
        }

        private void ApplyMapZoom()
        {
            if (Patches.MapPatch.MapCamera == null || Patches.MapPatch.DefaultMapZoom <= 0f)
                return;

            Patches.MapPatch.MapCamera.orthographicSize = Patches.MapPatch.DefaultMapZoom * Mathf.Max(0.25f, MapZoomMultiplier.Value);
        }

        private void SafetyScanExistingObjects()
        {
            if (Map.Instance == null)
                return;

            if (ShowEnemies.Value)
            {
                foreach (EnemyParent enemyParent in FindObjectsOfType<EnemyParent>())
                {
                    RegisterToMap(enemyParent);
                }
            }

            if (ShowPlayers.Value)
            {
                foreach (PlayerAvatar playerAvatar in FindObjectsOfType<PlayerAvatar>())
                {
                    if (playerAvatar != null && playerAvatar != PlayerController.instance?.playerAvatarScript)
                    {
                        RegisterToMap(playerAvatar);
                        ShowToMap(playerAvatar);
                    }
                }
            }
        }

        private GameObject GetVisualsFromComponent(Component component)
        {
            GameObject visuals = null;

            if (component is EnemyParent enemyParent)
            {
                Enemy enemy = null;
                enemy = TryGetEnemy(enemyParent);

                if (enemyParent.enemyName != "Bella")
                {
                    visuals = TryGetVisionObject(enemyParent);
                    if (visuals == null)
                    {
                        visuals = GetFirstComponentGameObject(enemyParent.EnableObject, "UnityEngine.Animator");
                    }
                }
                else if (enemy != null)
                {
                    visuals = TryGetTricycleTargetObject(enemy);
                }

                if (visuals == null && enemy != null)
                    visuals = enemy.gameObject;

                if (visuals == null)
                    visuals = enemyParent.gameObject;
            }
            else if (component is PlayerAvatar playerAvatar)
            {
                visuals = playerAvatar.playerAvatarVisuals != null ? playerAvatar.playerAvatarVisuals.gameObject : playerAvatar.gameObject;
            }

            return visuals;
        }

        private Enemy TryGetEnemy(EnemyParent enemyParent)
        {
            if (enemyParent == null || EnemyParentEnemyField == null)
                return null;

            try
            {
                return EnemyParentEnemyField.GetValue(enemyParent) as Enemy;
            }
            catch (Exception exception)
            {
                Logger.LogDebug($"Failed to read EnemyParent.Enemy: {exception.Message}");
                return null;
            }
        }

        private GameObject TryGetVisionObject(EnemyParent enemyParent)
        {
            try
            {
                EnemyVision vision = enemyParent.GetComponentInChildren<EnemyVision>();
                return vision?.VisionTransform != null ? vision.VisionTransform.gameObject : null;
            }
            catch (Exception exception)
            {
                Logger.LogDebug($"Failed to read enemy vision transform: {exception.Message}");
                return null;
            }
        }

        private GameObject TryGetTricycleTargetObject(Enemy enemy)
        {
            try
            {
                EnemyTricycle tricycle = enemy.GetComponentInChildren<EnemyTricycle>();
                return tricycle?.followTargetTransform != null ? tricycle.followTargetTransform.gameObject : null;
            }
            catch (Exception exception)
            {
                Logger.LogDebug($"Failed to read EnemyTricycle target: {exception.Message}");
                return null;
            }
        }

        private GameObject GetFirstComponentGameObject(GameObject rootObject, string componentTypeName)
        {
            if (rootObject == null || string.IsNullOrEmpty(componentTypeName))
                return null;

            Component[] components = rootObject.GetComponentsInChildren<Component>(true);
            for (int i = 0; i < components.Length; i++)
            {
                Component component = components[i];
                if (component == null)
                    continue;

                Type type = component.GetType();
                if (type.FullName == componentTypeName || type.Name == componentTypeName)
                    return component.gameObject;
            }

            return null;
        }

        internal void RegisterToMap(Component component)
        {
            if (Map.Instance == null || Map.Instance.CustomObject == null || Map.Instance.OverLayerParent == null || component == null)
                return;

            bool isEnemy = component is EnemyParent;
            bool isPlayer = component is PlayerAvatar;
            if ((!isEnemy || !ShowEnemies.Value) && (!isPlayer || !ShowPlayers.Value))
                return;

            List<MapInfo> list = isPlayer ? _playerMapInfos : _enemyMapInfos;
            if (list.Any(x => x.Component == component))
                return;

            if (isEnemy && IsEnemyExcluded((EnemyParent)component))
                return;

            GameObject visuals = GetVisualsFromComponent(component);
            if (visuals == null)
                return;

            GameObject mapObject = Instantiate(Map.Instance.CustomObject, Map.Instance.OverLayerParent);
            mapObject.name = "DarkSpider Map Tracker - " + visuals.name;

            MapCustomEntity mapCustomEntity = mapObject.GetComponent<MapCustomEntity>();
            if (mapCustomEntity == null)
            {
                Destroy(mapObject);
                return;
            }

            mapCustomEntity.Parent = visuals.transform;
            SpriteRenderer spriteRenderer = mapCustomEntity.spriteRenderer != null ? mapCustomEntity.spriteRenderer : mapObject.GetComponentInChildren<SpriteRenderer>(true);
            if (spriteRenderer == null)
            {
                Destroy(mapObject);
                return;
            }

            spriteRenderer.sprite = _arrowSprite;
            spriteRenderer.enabled = false;

            SpriteRenderer outlineRenderer = CreateOutlineRenderer(spriteRenderer);

            list.Add(new MapInfo
            {
                Component = component,
                MapCustomEntity = mapCustomEntity,
                SpriteRenderer = spriteRenderer,
                OutlineRenderer = outlineRenderer,
                Visible = false,
                IsPlayer = isPlayer
            });
        }

        private SpriteRenderer CreateOutlineRenderer(SpriteRenderer mainRenderer)
        {
            GameObject outlineObject = new GameObject("Arrow Outline");
            outlineObject.transform.SetParent(mainRenderer.transform, false);
            outlineObject.transform.localPosition = new Vector3(0f, -0.001f, 0f);
            outlineObject.transform.localRotation = Quaternion.identity;
            outlineObject.transform.localScale = Vector3.one * Mathf.Max(1f, OutlineScale.Value);

            SpriteRenderer outlineRenderer = outlineObject.AddComponent<SpriteRenderer>();
            outlineRenderer.sprite = _arrowSprite;
            outlineRenderer.color = ParseColor(OutlineColor.Value, Color.black);
            outlineRenderer.sortingLayerID = mainRenderer.sortingLayerID;
            outlineRenderer.sortingOrder = mainRenderer.sortingOrder - 1;
            outlineRenderer.enabled = false;
            return outlineRenderer;
        }

        internal void ShowToMap(Component component)
        {
            MapInfo mapInfo = FindMapInfo(component);
            if (mapInfo == null)
                return;

            if (component is EnemyParent enemyParent && IsEnemyExcluded(enemyParent))
                return;

            mapInfo.Visible = true;
        }

        internal void HideFromMap(Component component)
        {
            MapInfo mapInfo = FindMapInfo(component);
            if (mapInfo == null)
                return;

            mapInfo.Visible = false;
        }

        internal void SwapOnMap(Component component, Component fromComponent)
        {
            MapInfo mapInfo = FindMapInfo(component);
            MapInfo fromMapInfo = FindMapInfo(fromComponent);
            if (mapInfo == null || fromMapInfo == null)
                return;

            bool mapInfoIsEnemy = _enemyMapInfos.Contains(mapInfo);
            bool fromMapInfoIsEnemy = _enemyMapInfos.Contains(fromMapInfo);

            if (mapInfoIsEnemy == fromMapInfoIsEnemy)
                return;

            if (mapInfoIsEnemy)
            {
                _enemyMapInfos.Remove(mapInfo);
                _enemyMapInfos.Add(fromMapInfo);
                _playerMapInfos.Remove(fromMapInfo);
                _playerMapInfos.Add(mapInfo);
                mapInfo.IsPlayer = true;
                fromMapInfo.IsPlayer = false;
            }
            else
            {
                _playerMapInfos.Remove(mapInfo);
                _playerMapInfos.Add(fromMapInfo);
                _enemyMapInfos.Remove(fromMapInfo);
                _enemyMapInfos.Add(mapInfo);
                mapInfo.IsPlayer = false;
                fromMapInfo.IsPlayer = true;
            }
        }

        private MapInfo FindMapInfo(Component component)
        {
            if (component == null)
                return null;

            return _enemyMapInfos.FirstOrDefault(x => x.Component == component) ??
                   _playerMapInfos.FirstOrDefault(x => x.Component == component);
        }

        private void UpdateTracker(List<MapInfo> mapInfos, bool playerTracker)
        {
            if (Map.Instance == null)
                return;

            bool enabledByConfig = playerTracker ? ShowPlayers.Value : ShowEnemies.Value;

            for (int i = mapInfos.Count - 1; i >= 0; i--)
            {
                MapInfo mapInfo = mapInfos[i];
                if (mapInfo == null || mapInfo.Component == null || mapInfo.MapCustomEntity == null || mapInfo.SpriteRenderer == null)
                {
                    mapInfos.RemoveAt(i);
                    continue;
                }

                SpriteRenderer spriteRenderer = mapInfo.SpriteRenderer;
                SpriteRenderer outlineRenderer = mapInfo.OutlineRenderer;
                Transform parent = mapInfo.MapCustomEntity.Parent;
                if (parent == null)
                {
                    spriteRenderer.enabled = false;
                    if (outlineRenderer != null) outlineRenderer.enabled = false;
                    continue;
                }

                if (Map.Instance.Active)
                    Map.Instance.CustomPositionSet(mapInfo.MapCustomEntity.transform, parent);

                spriteRenderer.sprite = _arrowSprite;
                Color color = playerTracker ? GetPlayerArrowColor(mapInfo.Component as PlayerAvatar) : ParseColor(EnemyColor.Value, Color.red);

                MapLayer layerParent = Map.Instance.GetLayerParent(parent.position.y + 1f);
                color.a = layerParent != null && layerParent.layer == Map.Instance.PlayerLayer ? 1f : Mathf.Clamp01(OtherFloorAlpha.Value);

                float scale = playerTracker ? PlayerArrowScale.Value : EnemyArrowScale.Value;
                spriteRenderer.transform.localScale = Vector3.one * Mathf.Clamp(scale, 0.25f, 3.0f);

                spriteRenderer.color = color;
                spriteRenderer.enabled = enabledByConfig && mapInfo.Visible;

                if (outlineRenderer != null)
                {
                    Color outlineColor = ParseColor(OutlineColor.Value, Color.black);
                    outlineColor.a = color.a;
                    outlineRenderer.color = outlineColor;
                    outlineRenderer.transform.localScale = Vector3.one * Mathf.Max(1f, OutlineScale.Value);
                    outlineRenderer.enabled = OutlineEnabled.Value && enabledByConfig && mapInfo.Visible;
                }
            }
        }

        private Color GetPlayerArrowColor(PlayerAvatar playerAvatar)
        {
            if (playerAvatar != null && UsePlayerHeadColor.Value)
            {
                Color? cosmeticsColor = TryGetPlayerCosmeticsColor(playerAvatar);
                if (cosmeticsColor.HasValue)
                    return cosmeticsColor.Value;
            }

            return ParseColor(PlayerColor.Value, Color.cyan);
        }

        private Color? TryGetPlayerCosmeticsColor(PlayerAvatar playerAvatar)
        {
            try
            {
                PlayerCosmetics cosmetics = PlayerCosmeticsField?.GetValue(playerAvatar) as PlayerCosmetics;
                int[] equippedColors = PlayerCosmeticsColorsEquippedField?.GetValue(cosmetics) as int[];
                MetaManager metaManager = MetaManagerInstanceField?.GetValue(null) as MetaManager;
                List<SemiColor> metaColors = MetaManagerColorsField?.GetValue(metaManager) as List<SemiColor>;

                if (equippedColors == null || metaColors == null)
                    return null;

                for (int i = 0; i < equippedColors.Length; i++)
                {
                    int colorIndex = equippedColors[i];
                    if (colorIndex < 0 || colorIndex >= metaColors.Count || metaColors[colorIndex] == null)
                        continue;

                    object value = SemiColorColorField?.GetValue(metaColors[colorIndex]);
                    if (value is Color color)
                        return color;
                }
            }
            catch (Exception exception)
            {
                Logger.LogDebug($"Failed to read player cosmetics color: {exception.Message}");
            }

            return null;
        }

        private bool IsEnemyExcluded(EnemyParent enemyParent)
        {
            if (enemyParent == null)
                return false;

            string raw = ExcludeEnemies.Value ?? string.Empty;
            if (string.IsNullOrWhiteSpace(raw))
                return false;

            return raw.Split(',')
                .Select(x => x.Trim())
                .Where(x => !string.IsNullOrEmpty(x))
                .Any(x => x == enemyParent.enemyName);
        }

        private Color ParseColor(string htmlColor, Color fallback)
        {
            if (!string.IsNullOrWhiteSpace(htmlColor) && ColorUtility.TryParseHtmlString(htmlColor.Trim(), out Color color))
                return color;
            return fallback;
        }

        private void ClearMapInfos()
        {
            DestroyMapObjects(_enemyMapInfos);
            DestroyMapObjects(_playerMapInfos);
            _enemyMapInfos.Clear();
            _playerMapInfos.Clear();
        }

        private void DestroyMapObjects(List<MapInfo> mapInfos)
        {
            foreach (MapInfo mapInfo in mapInfos)
            {
                if (mapInfo?.MapCustomEntity != null)
                    Destroy(mapInfo.MapCustomEntity.gameObject);
            }
        }
    }
}
