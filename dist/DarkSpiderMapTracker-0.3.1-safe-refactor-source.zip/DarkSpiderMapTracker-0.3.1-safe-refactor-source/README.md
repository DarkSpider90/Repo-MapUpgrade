# DarkSpider Map Tracker 0.3.1 safe refactor

Safe cleanup based on the working 0.2.3 logic.

Important:
- EnemyParent is kept as object, not Component.
- Enemy registration still happens from EnemyParent patches.
- No FindObjectsOfType<EnemyParent>() safety scan.
- Player arrows are hidden when PlayerAvatar.isDisabled is true.
- Player head color uses colorsEquipped[5] / HeadTopMesh.
- Outline is enabled by default for white/gray visibility.
